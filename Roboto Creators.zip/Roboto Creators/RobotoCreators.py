import os
import json
import tkinter as tk
from tkinter import filedialog, messagebox
from resources.editor import start

APPDATA_PATH = os.path.join(os.getenv("LOCALAPPDATA"), "Roboto", "Roboto Creators", "mods")
os.makedirs(APPDATA_PATH, exist_ok=True)  # Ensure directory exists

root = tk.Tk()
root.title("Roboto Project Manager")
root.geometry("300x200")

def create_project():
    """Create a new project with mod selection."""
    onefile = tk.BooleanVar()
    create_window = tk.Toplevel(root)
    create_window.title("Create Project")
    create_window.geometry("400x400")
    create_window.resizable(False, False)
    
    tk.Label(create_window, text="Project Name:").pack()
    project_name_entry = tk.Entry(create_window)
    project_name_entry.pack()

    checkbox = tk.Checkbutton(create_window, text="Onefile", variable=onefile)
    checkbox.pack()
    
    tk.Label(create_window, text="Available Mods:").pack()
    mod_checkboxes = {}
    
    for mod in os.listdir(APPDATA_PATH):
        mod_path = os.path.join(APPDATA_PATH, mod)
        if os.path.isdir(mod_path):
            var = tk.BooleanVar()
            chk = tk.Checkbutton(create_window, text=mod, variable=var)
            chk.pack(anchor="w")
            mod_checkboxes[mod] = var
    
    def browse_directory():
        folder_selected = filedialog.askdirectory()
        if folder_selected:
            directory_label.config(text=folder_selected)
    
    directory_label = tk.Label(create_window, text="No directory selected")
    directory_label.pack()
    browse_button = tk.Button(create_window, text="Browse", command=browse_directory)
    browse_button.pack()
    
    def finalize_creation():
        """Save project info and start the editor."""
        project_name = project_name_entry.get().strip()
        project_directory = directory_label.cget("text")
        
        if not project_name:
            messagebox.showerror("Error", "Project name is required!")
            return
        if project_directory == "No directory selected":
            messagebox.showerror("Error", "Please select a project directory!")
            return
        
        project_path = os.path.join(project_directory, project_name)
        os.makedirs(project_path, exist_ok=True)
        
        active_mods = [mod for mod, var in mod_checkboxes.items() if var.get()]
        
        info = {
            "name": project_name,
            "mods": active_mods,
            "onefile": onefile
        }
        
        with open(os.path.join(project_path, "info.json"), "w") as f:
            json.dump(info, f, indent=4)
        
        start(project_name, active_mods)
        create_window.destroy()
        root.destroy()
    
    create_button = tk.Button(create_window, text="Create", command=finalize_creation)
    create_button.pack()

def open_project():
    """Open an existing project and load its mods."""
    project_path = filedialog.askdirectory(title="Select Project Directory")
    
    if project_path:
        info_file = os.path.join(project_path, "info.json")
        if not os.path.exists(info_file):
            messagebox.showerror("Error", "Invalid project! No info.json found.")
            return
        
        with open(info_file, "r") as f:
            project_info = json.load(f)
        
        project_name = project_info.get("name", "Unknown Project")
        active_mods = project_info.get("mods", [])
        
        start(project_name, active_mods)

tk.Button(root, text="Create", bg="blue", fg="white", command=create_project).pack(pady=20)
tk.Button(root, text="Open", bg="blue", fg="white", command=open_project).pack(pady=20)

root.mainloop()
