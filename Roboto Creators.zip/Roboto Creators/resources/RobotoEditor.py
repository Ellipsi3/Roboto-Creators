import sys
import psutil
from plyer import notification

# Disable the creation of .pyc files
sys.dont_write_bytecode = True

class App():
    def Close():
        sys.exit()
    def SendNotification(title, message, time):
        notification.notify(
        title=title,
        message=message,
        timeout=time  # Notification disappears after 5 seconds
    )

class System():
    def GetMemory(type="GB"):
        virtual_memory = psutil.virtual_memory()

        if type == "GB":
            total = virtual_memory.total / (1024 ** 3)  # Convert to GB
        elif type == "MB":
            total = virtual_memory.total / (1024 ** 2)  # Convert to MB
        else:
            raise ValueError("Invalid type. Use 'GB' or 'MB'.")

        return f"{total:.2f} {type}"
    
    def GetMemoryUsage(unit="GB"):
        virtual_memory = psutil.virtual_memory()
        used_memory = virtual_memory.used  # Get used RAM instead of total

        if unit == "GB":
            used_memory /= (1024 ** 3)  # Convert to GB
        elif unit == "MB":
            used_memory /= (1024 ** 2)  # Convert to MB
        else:
            raise ValueError("Invalid type. Use 'GB' or 'MB'.")

        return f"{used_memory:.2f} {unit}"
    
    def GetCPU():
        cpu_usage = psutil.cpu_percent(interval=1)  # Get CPU usage over 1 second
        return f"{cpu_usage:.2f}%"