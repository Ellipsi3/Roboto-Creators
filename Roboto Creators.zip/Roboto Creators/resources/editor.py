import tkinter as tk
import os

# Path to the mods directory
MODS_DIR = os.path.expandvars(r"%LOCALAPPDATA%\Roboto\Roboto Creators\mods")

def load_mods(active_mods, root, left_frame):
    """Load and execute Python code from active mod function.dll files."""
    for mod in active_mods:
        mod_path = os.path.join(MODS_DIR, mod, "function.dll")
        
        if os.path.exists(mod_path):
            try:
                with open(mod_path, "r", encoding="utf-8") as file:
                    mod_code = file.read()
                    
                    # Create a separate namespace (a dictionary) to execute the code
                    mod_namespace = {}
                    exec(mod_code, mod_namespace)

                    print(f"Loaded mod: {mod}")
                    
                    # If the "Resizable Dimensions" mod is active, modify the left_frame
                    if mod == "Resizable Dimensions":
                        # Dynamically check if the function exists in the namespace
                        if 'modify_left_frame_gui' in mod_namespace:
                            modify_left_frame_gui = mod_namespace['modify_left_frame_gui']
                            modify_left_frame_gui(root, left_frame)
                        else:
                            print(f"No 'modify_left_frame_gui' function in {mod}'s function.dll")

            except Exception as e:
                print(f"Failed to load mod {mod}: {e}")
        else:
            print(f"Mod {mod} does not contain function.dll")

def start(project_name: str, active_mods: list):
    """Start the editor and load active mods."""
    root = tk.Tk()
    root.title("Editing: " + project_name)
    root.state('zoomed')

    # Create the left_frame as the initial frame
    left_frame = tk.Frame(root, width=800, height=800, bg="gray")
    left_frame.pack(side="top", expand=True)  # Centers the frame in the window

    # Load and apply active mods
    load_mods(active_mods, root, left_frame)

    root.mainloop()
